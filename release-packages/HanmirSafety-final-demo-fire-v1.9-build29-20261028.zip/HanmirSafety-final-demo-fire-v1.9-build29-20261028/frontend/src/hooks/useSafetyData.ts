import {useCallback, useEffect, useRef, useState} from "react";
import {App} from "@capacitor/app";
import {Network} from "@capacitor/network";
import {api, auth} from "../services/api";
import {getWsBaseUrl} from "../services/config";
import {mergeWorkerPosition,positionTimestamp} from "../services/positionUpdates";
import type {LocationPoint, Snapshot, Worker, EvacuationSnapshot} from "../types";

export type ConnectionState = "connected" | "connecting" | "reconnecting" | "offline" | "error";

export function useSafetyData(enabled = true) {
  const [data, setData] = useState<Snapshot | null>(null);
  const [locationHistory, setLocationHistory] = useState<Record<string, LocationPoint[]>>({});
  const [connected, setConnected] = useState(false);
  const [serverReachable, setServerReachable] = useState(false);
  const [connectionState, setConnectionState] = useState<ConnectionState>("connecting");
  const [reconnectAttempts, setReconnectAttempts] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const pollTimerRef = useRef<number | undefined>(undefined);
  const socketRef = useRef<WebSocket | null>(null);
  const reconnectTimerRef = useRef<number | undefined>(undefined);
  const heartbeatTimerRef = useRef<number | undefined>(undefined);
  const backoffRef = useRef<number>(2000);
  const attemptsRef = useRef<number>(0);
  const disposedRef = useRef<boolean>(false);
  const isConnectingRef = useRef<boolean>(false);
  const refreshInFlightRef = useRef(false);
  const historyRefreshAtRef = useRef(0);

  const refresh = useCallback(async () => {
    if (!auth.getToken() || refreshInFlightRef.current) return;
    refreshInFlightRef.current = true;
    try {
      const snapshot = await api.snapshot();
      setData(current => ({...snapshot,
        workers:snapshot.workers.map(worker=>mergeWorkerPosition(worker,current?.workers.find(item=>item.worker_id===worker.worker_id))),
        devices: snapshot.devices.map(device => {
        const live = current?.devices.find(item => item.device_id === device.device_id);
        if (!live?.heading_at || Date.parse(live.heading_at) <= Date.parse(device.heading_at ?? "1970-01-01")) return device;
        return {...device, heading_deg: live.heading_deg, heading_at: live.heading_at,
          component_status: {...device.component_status, imu: live.component_status?.imu,
            imu_yaw_deg: live.component_status?.imu_yaw_deg,
            imu_pitch_deg: live.component_status?.imu_pitch_deg, imu_roll_deg: live.component_status?.imu_roll_deg,
            imu_received_at: live.heading_at, heading_transport: live.component_status?.heading_transport}};
      })}));
      setServerReachable(true);
      if (Date.now() - historyRefreshAtRef.current >= 15000) {
      historyRefreshAtRef.current = Date.now();
      const histories = await Promise.all(
        snapshot.workers.map(async worker => {
          try {
            return [worker.worker_id, await api.locationHistory(worker.worker_id)] as const;
          } catch {
            return [worker.worker_id, []] as const;
          }
        })
      );
      setLocationHistory(Object.fromEntries(histories));
      }
      setError(null);
    } catch (cause) {
      const msg = cause instanceof Error ? cause.message : "서버 연결에 실패했습니다.";
      if (msg.includes("로그인이 필요")) {
        setData(null);
        setLocationHistory({});
      }
      setServerReachable(false);
      setError(msg);
    } finally {
      refreshInFlightRef.current = false;
    }
  }, []);

  const refreshRef = useRef(refresh);
  refreshRef.current = refresh;

  const connectWebSocket = useCallback(() => {
    if (disposedRef.current || isConnectingRef.current) return;

    const token = auth.getToken();
    if (!token) return;

    if (socketRef.current) {
      try {
        socketRef.current.onclose = null;
        socketRef.current.onerror = null;
        socketRef.current.close();
      } catch {
        // ignore
      }
      socketRef.current = null;
    }

    const wsBase = getWsBaseUrl();
    isConnectingRef.current = true;
    setConnectionState(attemptsRef.current > 0 ? "reconnecting" : "connecting");

    try {
      const socket = new WebSocket(`${wsBase}/ws/dashboard?token=${encodeURIComponent(token)}`);
      socketRef.current = socket;

      socket.onopen = () => {
        isConnectingRef.current = false;
        if (disposedRef.current) {
          socket.close();
          return;
        }
        setConnected(true);
        setConnectionState("connected");
        attemptsRef.current = 0;
        setReconnectAttempts(0);
        backoffRef.current = 2000;
        socket.send("dashboard-ready");

        // Start heartbeat ping
        if (heartbeatTimerRef.current) window.clearInterval(heartbeatTimerRef.current);
        heartbeatTimerRef.current = window.setInterval(() => {
          if (socket.readyState === WebSocket.OPEN) {
            try {
              socket.send(JSON.stringify({type: "ping", timestamp: Date.now()}));
            } catch {
              // ignore
            }
          }
        }, 15000);
      };

      socket.onmessage = event => {
        if (disposedRef.current) return;
        try {
          const message = JSON.parse(event.data) as {
            type: string;
            data?: Partial<EvacuationSnapshot> & {worker?: Worker; location?: {x: number; y: number; confidence: number};
              device_id?: string; imu_yaw_deg?: number; imu_pitch_deg?: number; imu_roll_deg?: number; heading_at?: string};
          };
          if (message.type === "evacuation_navigation" && message.data?.routes) {
            const navigation = message.data as EvacuationSnapshot;
            setData(current => current ? {...current, evacuation: navigation} : current);
            return;
          }
          if (message.type === "pong") {
            return;
          }
          // Raw IMU diagnostics have their own capture API. Do not reload the
          // complete dashboard twice a second while a diagnostic run is active.
          if (message.type === 'imu_summary' || message.type === 'imu_candidate') return;
          if (message.type === "orientation" && message.data?.device_id) {
            const sample = message.data;
            if (typeof sample.imu_yaw_deg !== "number" || !Number.isFinite(sample.imu_yaw_deg) || !sample.heading_at) return;
            setData(current => current ? {...current, devices: current.devices.map(device => {
              if (device.device_id !== sample.device_id || Date.parse(sample.heading_at!) <= Date.parse(device.heading_at ?? "1970-01-01")) return device;
              const calibration = device.component_status?.heading_calibration as {offset_deg?: number} | undefined;
              const offset = calibration?.offset_deg;
              return {...device, online: true,
                heading_deg: typeof offset === "number" ? ((sample.imu_yaw_deg! + offset) % 360 + 360) % 360 : null,
                heading_at: sample.heading_at!, component_status: {...device.component_status,
                  imu: "ready", imu_yaw_deg: sample.imu_yaw_deg!, imu_pitch_deg: sample.imu_pitch_deg ?? 0,
                  imu_roll_deg: sample.imu_roll_deg ?? 0, imu_received_at: sample.heading_at!, heading_transport: "websocket"}};
            })} : current);
            return;
          }
          if (message.type === "location" && message.data?.worker && message.data.location) {
            const worker = message.data.worker;
            const location = message.data.location;
            const receivedAt = worker.position_status?.server_received_at ?? new Date().toISOString();
            setData(current => current ? {
              ...current,
              workers: current.workers.map(item => item.worker_id === worker.worker_id ? mergeWorkerPosition(worker,item) : item),
              devices: current.devices.map(device => device.worker_id === worker.worker_id && device.device_type === "position_device"
                ? {...device, online: true, last_uwb_at: receivedAt, last_seen: receivedAt}
                : device)
            } : current);
            setLocationHistory(current => {
              const existing=current[worker.worker_id]??[];
              const last=existing[existing.length-1];
              if(last && positionTimestamp(worker)<=Date.parse(last.created_at))return current;
              const points = [...existing, {
                x: location.x,
                y: location.y,
                confidence: location.confidence,
                created_at: receivedAt
              }].slice(-500);
              return {...current, [worker.worker_id]: points};
            });
            return;
          }
        } catch {
          // ignore parse errors
        }
        void refreshRef.current();
      };

      socket.onclose = () => {
        isConnectingRef.current = false;
        if (heartbeatTimerRef.current) window.clearInterval(heartbeatTimerRef.current);
        setConnected(false);
        if (disposedRef.current) return;

        attemptsRef.current += 1;
        setReconnectAttempts(attemptsRef.current);
        setConnectionState("reconnecting");

        // Stable exponential backoff (min 3000ms, max 20000ms) to prevent socket flooding
        const delay = Math.min(backoffRef.current, 20000);
        backoffRef.current = Math.min(backoffRef.current * 1.5, 20000);

        if (reconnectTimerRef.current) window.clearTimeout(reconnectTimerRef.current);
        reconnectTimerRef.current = window.setTimeout(() => {
          connectWebSocket();
        }, delay);
      };

      socket.onerror = () => {
        isConnectingRef.current = false;
        setConnected(false);
        setConnectionState("error");

        // iOS Safari can keep a failed socket in CONNECTING/CLOSING state after
        // Wi-Fi returns and delay its close event.  Do not wait indefinitely for
        // that event: replace the stale socket shortly afterwards.
        window.setTimeout(() => {
          if (disposedRef.current || socketRef.current !== socket || socket.readyState === WebSocket.OPEN) return;
          connectWebSocket();
        }, 800);
      };
    } catch {
      isConnectingRef.current = false;
      setConnected(false);
      setConnectionState("error");
    }
  }, []);

  const forceReconnect = useCallback(() => {
    backoffRef.current = 2000;
    attemptsRef.current = 0;
    setReconnectAttempts(0);
    setConnectionState("connecting");
    if (reconnectTimerRef.current) window.clearTimeout(reconnectTimerRef.current);
    void refresh();
    connectWebSocket();
  }, [connectWebSocket, refresh]);

  useEffect(() => {
    if (!enabled) {
      disposedRef.current = true;
      setData(null);
      setLocationHistory({});
      historyRefreshAtRef.current = 0;
      setConnected(false);
      setServerReachable(false);
      setConnectionState("offline");
      setReconnectAttempts(0);
      setError(null);
      attemptsRef.current = 0;
      isConnectingRef.current = false;
      window.clearInterval(pollTimerRef.current);
      window.clearTimeout(reconnectTimerRef.current);
      window.clearInterval(heartbeatTimerRef.current);
      if (socketRef.current) {
        socketRef.current.onclose = null;
        socketRef.current.onerror = null;
        socketRef.current.close();
        socketRef.current = null;
      }
      return;
    }

    disposedRef.current = false;
    void refresh();
    pollTimerRef.current = window.setInterval(refresh, 3000);

    connectWebSocket();

    // 1. Mobile App lifecycle handler (Background -> Foreground)
    let appStateHandle: {remove: () => Promise<void>} | null = null;
    void App.addListener("appStateChange", state => {
      if (state.isActive) {
        void refresh();
        if (!socketRef.current || socketRef.current.readyState !== WebSocket.OPEN) {
          forceReconnect();
        }
      }
    }).then(h => {
      appStateHandle = h;
    }).catch(() => {});

    // 2. Mobile Network state change (Offline -> Online)
    let networkHandle: {remove: () => Promise<void>} | null = null;
    void Network.addListener("networkStatusChange", status => {
      if (status.connected) {
        void refresh();
        if (!socketRef.current || socketRef.current.readyState !== WebSocket.OPEN) {
          forceReconnect();
        }
      } else {
        setConnected(false);
        setConnectionState("offline");
      }
    }).then(h => {
      networkHandle = h;
    }).catch(() => {});

    // 3. Fallback window online/offline listeners
    const handleOnline = () => {
      void refresh();
      forceReconnect();
    };
    const handleOffline = () => {
      setConnected(false);
      setConnectionState("offline");
    };

    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    return () => {
      disposedRef.current = true;
      isConnectingRef.current = false;
      window.clearInterval(pollTimerRef.current);
      window.clearTimeout(reconnectTimerRef.current);
      window.clearInterval(heartbeatTimerRef.current);
      if (socketRef.current) {
        try {
          socketRef.current.onopen = null;
          socketRef.current.onmessage = null;
          socketRef.current.onclose = null;
          socketRef.current.onerror = null;
          socketRef.current.close();
        } catch {
          // ignore
        }
        socketRef.current = null;
      }
      if (appStateHandle) void appStateHandle.remove();
      if (networkHandle) void networkHandle.remove();
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, [enabled, connectWebSocket, forceReconnect, refresh]);

  return {
    data,
    locationHistory,
    connected,
    serverReachable,
    connectionState,
    reconnectAttempts,
    error,
    refresh,
    forceReconnect
  };
}
