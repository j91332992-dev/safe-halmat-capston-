import json

from fastapi.testclient import TestClient

from app.database import SessionLocal
from app.main import app
from app.models.entities import Device, EvacuationIncident, WorkerState
from app.routers.auth import demo_session_active
from app.services.demo_fire_service import activate_demo_voice_fire, close_demo_incident, ingest_imu_motion
from app.services.evacuation_service import calculate_route
from app.services.orientation_service import record_orientation


def test_demo_account_is_explicit_and_production_account_is_unchanged():
    with TestClient(app) as client:
        production = client.post("/api/auth/login", json={"username": "TUTUS", "password": "0000"})
        demo = client.post("/api/auth/login", json={"username": "DEMO", "password": "0000"})
        assert production.status_code == 200
        assert production.json()["account_mode"] == "production"
        assert demo.status_code == 200
        assert demo.json()["account_mode"] == "demo"
        assert production.json()["site_id"] == demo.json()["site_id"] == "site-001"
        client.post("/api/auth/logout", headers={"Authorization": f"Bearer {demo.json()['token']}"})
        client.post("/api/auth/logout", headers={"Authorization": f"Bearer {production.json()['token']}"})


def test_demo_voice_fire_uses_virtual_map_and_imu_steps_only_with_demo_login():
    with TestClient(app) as client:
        login = client.post("/api/auth/login", json={"username": "DEMO", "password": "0000"})
        token = login.json()["token"]
        assert demo_session_active("site-001")
        record_orientation("helmet-001-av", {"yaw_deg": 12.0, "pitch_deg": 0.0, "roll_deg": 0.0})
        with SessionLocal() as db:
            worker = db.get(WorkerState, "worker-001")
            incident, created, enabled = activate_demo_voice_fire(
                db, worker, "helmet-001-av", "화재 발생"
            )
            db.commit()
            assert created and enabled and incident.status == "active"
            details = json.loads(incident.details_json)
            assert details["demo_mode"] is True
            assert details["navigation_enabled"] is True
            route = calculate_route(db, worker, incident)
            assert route["available"] is True
            assert route["path"]
            before = (worker.x, worker.y)

        packet = {
            "boot": "1234abcd",
            "records": [
                [1, 1, 3, 1_000_000, 1_000_000, 0.0, 0.0, 9.81, 0.0],
                [1, 2, 3, 1_400_000, 1_400_000, 0.0, 0.0, 13.0, 0.0],
            ],
        }
        result = ingest_imu_motion("helmet-001-av", "site-001", packet)
        assert result and result["location"]["source"] == "demo_imu"
        assert result["location"]["steps"] == 1
        assert (result["location"]["x"], result["location"]["y"]) != before

        logout = client.post("/api/auth/logout", headers={"Authorization": f"Bearer {token}"})
        assert logout.status_code == 200
        assert not demo_session_active("site-001")
        with SessionLocal() as db:
            incident = db.query(EvacuationIncident).filter(EvacuationIncident.source == "voice_demo").order_by(EvacuationIncident.created_at.desc()).first()
            assert incident and incident.status == "resolved"


def test_no_demo_session_cannot_apply_virtual_motion():
    with SessionLocal() as db:
        close_demo_incident(db, "site-001")
    packet = {"boot": "87654321", "records": [[1, 1, 3, 1_000_000, 1_000_000, 0.0, 0.0, 13.0, 0.0]]}
    assert ingest_imu_motion("helmet-001-av", "site-001", packet) is None
