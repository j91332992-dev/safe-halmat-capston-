"""Account-gated virtual UWB motion for the spoken fire demonstration.

Production UWB remains authoritative unless an unexpired DEMO login exists and
the current incident was created by this service.  No state survives a restart.
"""
from __future__ import annotations

import hashlib
import json
import math
from time import monotonic
from types import SimpleNamespace

from ..database import SessionLocal, utcnow
from ..models.entities import Device, EvacuationIncident, Location, SiteLayout, WorkerState
from .orientation_service import live_status

STEP_LENGTH_M = 0.65
STEP_PEAK_MPS2 = 1.15
STEP_RESET_MPS2 = 0.45
STEP_REFRACTORY_SECONDS = 0.32
LOCATION_REFRESH_SECONDS = 0.45

_motion: dict[str, dict] = {}


def _demo_map(width: float, height: float) -> dict:
    width, height = max(4.0, width), max(5.5, height)
    return {
        "width": width,
        "height": height,
        "start": {"x": round(width * 0.16, 2), "y": round(height * 0.84, 2)},
        "fire_zone": {"name": "가상 화재 구역", "x": round(width * 0.68, 2),
                      "y": round(height * 0.61, 2), "width": 0.8, "height": 0.8},
        "objects": [
            {"obstacle_id": "demo-wall-1", "name": "가상 중앙 벽",
             "object_type": "wall", "x": round(width * 0.46, 2), "y": round(height * 0.20, 2),
             "width": 0.22, "height": round(height * 0.52, 2)},
            {"obstacle_id": "demo-wall-2", "name": "가상 설비 벽",
             "object_type": "wall", "x": round(width * 0.68, 2), "y": round(height * 0.48, 2),
             "width": round(width * 0.20, 2), "height": 0.22},
            {"obstacle_id": "demo-exit-main", "name": "가상 주 비상구",
             "object_type": "emergency_exit", "x": round(width - 0.85, 2), "y": 0.0,
             "width": 0.8, "height": 0.25},
        ],
    }


def demo_map_signature(data: dict) -> str:
    encoded = json.dumps(data, sort_keys=True, ensure_ascii=False).encode("utf-8")
    return "demo:" + hashlib.sha256(encoded).hexdigest()


def demo_objects(data: dict) -> list:
    return [SimpleNamespace(**item) for item in data.get("objects", [])]


def _raw_yaw(device: Device) -> tuple[float | None, str | None]:
    status = live_status(device.device_id, json.loads(device.component_status_json or "{}"))
    yaw = status.get("imu_yaw_deg")
    return (float(yaw), status.get("imu_received_at")) if isinstance(yaw, (int, float)) and math.isfinite(yaw) else (None, None)


def activate_demo_voice_fire(db, worker: WorkerState, device_id: str, text: str):
    from .evacuation_service import current_incident, trigger_fire

    existing = current_incident(db, worker.site_id)
    if existing and not json.loads(existing.details_json or "{}").get("demo_mode"):
        # A genuine incident must never be converted into a demonstration.
        return existing, False, False
    incident, created = trigger_fire(db, "voice_demo", worker.worker_id, {"text": text})
    layout = db.get(SiteLayout, worker.site_id)
    demo_map = _demo_map(layout.width if layout else 5.8, layout.height if layout else 8.2)
    device = db.get(Device, device_id)
    yaw, _ = _raw_yaw(device) if device else (None, None)
    # At activation, the wearer's current facing is virtual north.
    heading_offset = (90.0 - yaw) if yaw is not None else 0.0
    details = json.loads(incident.details_json or "{}")
    details.update({
        "demo_mode": True,
        "demo_account": "DEMO",
        "demo_map": demo_map,
        "demo_map_signature": demo_map_signature(demo_map),
        "demo_heading_offset_deg": heading_offset,
        "demo_step_length_m": STEP_LENGTH_M,
        "navigation_enabled": True,
        "navigation_auto": True,
        "navigation_map_signature": demo_map_signature(demo_map),
    })
    incident.status = "active"
    incident.fire_zone_json = json.dumps(demo_map["fire_zone"], ensure_ascii=False)
    incident.details_json = json.dumps(details, ensure_ascii=False)
    start = demo_map["start"]
    worker.x, worker.y, worker.confidence = start["x"], start["y"], 0.98
    worker.last_valid_location_at = utcnow()
    worker.last_valid_location_json = json.dumps({"x": worker.x, "y": worker.y,
                                                   "confidence": worker.confidence, "source": "demo_imu"})
    worker.position_status_json = json.dumps({"accepted": True, "applied": True,
                                              "mode": "demo_imu", "source": "demo"})
    _motion[device_id] = {"gravity": 9.81, "armed": True, "last_step": 0.0,
                          "last_refresh": 0.0, "boot": None}
    db.flush()
    return incident, created, True


def is_demo_incident(db, site_id: str) -> bool:
    from .evacuation_service import current_incident
    from ..routers.auth import demo_session_active
    incident = current_incident(db, site_id)
    return bool(demo_session_active(site_id) and incident and
                json.loads(incident.details_json or "{}").get("demo_mode"))


def close_demo_incident(db, site_id: str) -> bool:
    from .evacuation_service import current_incident
    incident = current_incident(db, site_id)
    if not incident:
        return False
    details = json.loads(incident.details_json or "{}")
    if not details.get("demo_mode"):
        return False
    details["navigation_enabled"] = False
    details["demo_closed"] = True
    incident.details_json = json.dumps(details, ensure_ascii=False)
    incident.status = "resolved"
    incident.cancel_reason = "demo_logout"
    db.commit()
    return True


def demo_heading(device: Device, details: dict) -> tuple[float | None, str | None]:
    yaw, received = _raw_yaw(device)
    if yaw is None:
        return None, received
    return (yaw + float(details.get("demo_heading_offset_deg", 0.0))) % 360, received


def _inside_object(x: float, y: float, item: dict, padding: float = 0.20) -> bool:
    if item.get("object_type") not in {"wall", "obstacle"}:
        return False
    return (float(item["x"]) - padding <= x <= float(item["x"]) + float(item["width"]) + padding and
            float(item["y"]) - padding <= y <= float(item["y"]) + float(item["height"]) + padding)


def ingest_imu_motion(device_id: str, site_id: str, packet: dict) -> dict | None:
    """Convert BNO085 walking peaks to a bounded virtual position."""
    from ..routers.auth import demo_session_active
    if not demo_session_active(site_id):
        return None
    now = monotonic()
    state = _motion.setdefault(device_id, {"gravity": 9.81, "armed": True,
                                            "last_step": 0.0, "last_refresh": 0.0, "boot": None})
    if state.get("boot") != packet.get("boot"):
        state.update(gravity=9.81, armed=True, last_step=0.0, boot=packet.get("boot"))
    steps = 0
    for row in packet.get("records", []):
        if row[0] != 1:
            continue
        magnitude = math.sqrt(float(row[5]) ** 2 + float(row[6]) ** 2 + float(row[7]) ** 2)
        state["gravity"] = 0.96 * state["gravity"] + 0.04 * magnitude
        dynamic = abs(magnitude - state["gravity"])
        sample_time = float(row[3]) / 1_000_000.0
        if state["armed"] and dynamic >= STEP_PEAK_MPS2 and sample_time - state["last_step"] >= STEP_REFRACTORY_SECONDS:
            state.update(armed=False, last_step=sample_time)
            steps += 1
        elif dynamic <= STEP_RESET_MPS2:
            state["armed"] = True
    if not steps and now - state["last_refresh"] < LOCATION_REFRESH_SECONDS:
        return None
    with SessionLocal() as db:
        from .evacuation_service import current_incident
        incident = current_incident(db, site_id)
        details = json.loads(incident.details_json or "{}") if incident else {}
        if not incident or not details.get("demo_mode") or not details.get("navigation_enabled"):
            return None
        device = db.get(Device, device_id)
        worker = db.get(WorkerState, device.worker_id) if device and device.site_id == site_id else None
        if not worker:
            return None
        heading, heading_at = demo_heading(device, details)
        moved = False
        if steps and heading is not None:
            distance = min(steps, 3) * float(details.get("demo_step_length_m", STEP_LENGTH_M))
            angle = math.radians(heading)
            candidate_x = worker.x + math.cos(angle) * distance
            candidate_y = worker.y + math.sin(angle) * distance
            demo_map = details["demo_map"]
            candidate_x = max(0.25, min(float(demo_map["width"]) - 0.25, candidate_x))
            candidate_y = max(0.25, min(float(demo_map["height"]) - 0.25, candidate_y))
            fire = demo_map.get("fire_zone") or {}
            blocked = any(_inside_object(candidate_x, candidate_y, item) for item in demo_map.get("objects", []))
            blocked = blocked or _inside_object(candidate_x, candidate_y,
                                                 {**fire, "object_type": "obstacle"}, 0.55)
            if not blocked:
                worker.x, worker.y = round(candidate_x, 3), round(candidate_y, 3)
                moved = True
        worker.confidence = 0.98
        worker.last_valid_location_at = utcnow()
        worker.last_valid_location_json = json.dumps({"x": worker.x, "y": worker.y,
                                                       "confidence": worker.confidence, "source": "demo_imu"})
        worker.position_status_json = json.dumps({"accepted": True, "applied": True, "mode": "demo_imu",
                                                  "source": "demo", "steps": steps, "heading_deg": heading})
        if moved:
            db.add(Location(worker_id=worker.worker_id, site_id=site_id, x=worker.x, y=worker.y,
                            confidence=worker.confidence,
                            distances_json=json.dumps({"source": "demo_imu_step", "steps": steps,
                                                       "heading_deg": heading})))
        db.commit()
        state["last_refresh"] = now
        return {"site_id": site_id, "worker_id": worker.worker_id,
                "location": {"x": worker.x, "y": worker.y, "confidence": worker.confidence,
                             "changed": moved, "source": "demo_imu", "steps": steps,
                             "heading_deg": heading, "heading_at": heading_at}}
