import logging

from ..config import settings
from .speech_service import normalize

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """당신은 스마트 안전모의 한국어 안전 AI '투투스'입니다.
작업자의 현재 위치, 위험도, 보호구와 감지 위험을 근거로 답하세요.
핵심만 한국어 한 문장, 꼭 필요할 때만 두 문장으로 답하세요. 인사말과 서두는 생략하세요.
비상 또는 도움 요청이면 즉시 관제실 전송 사실과 안전한 대피를 강조하세요.
화재 시 제공된 화재 위치와 비상구 거리만 말하고 좌회전, 우회전, 직진 같은 방향 지시는 만들지 마세요.
제공되지 않은 사실이나 센서 값을 만들어내지 마세요."""


FAST_INTENTS = {"call_manager", "status_report", "location_query", "risk_query", "help", "emergency", "fire_report", "fire_confirm", "evacuation_route", "repeat_warning"}
FAST_INTENTS.update({"battery_query", "ppe_query", "device_query", "heading_query"})


def build_response(intent: str, worker: dict) -> tuple[str, str | None]:
    freshness = worker.get("data_freshness")
    if freshness is not None:
        if intent == "location_query" and not freshness.get("location"):
            return "현재 위치는 확인 불가입니다. UWB 연결을 확인해 주세요.", "play_tone"
        if intent in {"ppe_query", "risk_query", "status_report"} and not freshness.get("vision") and not worker.get("emergency"):
            return "최신 센서 정보가 없어 현재 상태는 확인 불가입니다.", "play_tone"
    if intent == "battery_query":
        battery = worker.get("battery")
        return (f"현재 배터리는 {battery:.0f}퍼센트입니다." if battery is not None else "현재 배터리는 확인 불가입니다."), "play_tone"
    if intent == "device_query":
        return ("장치가 연결되어 있습니다." if freshness and freshness.get("device") else "장치 연결은 확인 불가입니다."), "play_tone"
    if intent == "heading_query":
        return "현재 방향은 확인 불가입니다. 방향 센서 검증이 필요합니다.", "play_tone"
    if intent == "ppe_query":
        ppe = worker.get("ppe") or {}
        labels = {"helmet": "안전모", "vest": "조끼", "glove": "장갑", "gloves": "장갑"}
        parts = [f"{label} {'착용' if ppe[key] else '미착용'}" for key, label in labels.items() if isinstance(ppe.get(key), bool)]
        return ("현재 " + ", ".join(parts) + "입니다." if parts else "보호구 상태는 확인 불가입니다."), "play_tone"
    decision = worker.get("decision") or {}
    current_warning = decision.get("voice_message") or "현재 확인된 경고가 없습니다."
    evacuation = worker.get("evacuation") or {}
    route_instruction = str(evacuation.get("message") or (evacuation.get("instructions") or ["화재 위치 또는 비상구 거리를 확인할 수 없습니다. 비상 유도등을 확인하고 즉시 대피하세요."])[0])
    responses = {
        "call_manager": ("네, 알겠습니다.", "play_tone"),
        "status_report": (current_warning if decision.get("priority", 5) < 5 else f"현재 상태는 {worker.get('risk_level', '알 수 없음')}입니다.", "play_alert" if decision.get("priority", 5) <= 2 else "play_tone"),
        "location_query": (f"현재 위치는 X {worker.get('x', 0):.1f}, Y {worker.get('y', 0):.1f} 미터입니다.", "play_tone"),
        "risk_query": (current_warning if decision.get("priority", 5) < 5 else f"현재 위험도는 {worker.get('risk_score', 0)}점, {worker.get('risk_level', '알 수 없음')} 단계입니다.", "play_alert" if decision.get("priority", 5) <= 2 else "play_tone"),
        "help": ("도움 요청을 관제실에 전송했습니다. 안전한 장소에서 대기하세요.", "play_alert"),
        "emergency": ("비상 신고를 접수했습니다. 즉시 위험 장소에서 대피하세요.", "play_alert"),
        "fire_confirm": ("화재가 확정됐습니다. " + route_instruction, "play_alert"),
        "fire_report": ("화재 신고를 접수했습니다. " + route_instruction, "play_alert"),
        "evacuation_route": (route_instruction, "play_alert"),
        "repeat_warning": (current_warning, "play_alert"),
    }
    return responses.get(intent, ("다시 한 번 말씀해 주세요.", "play_tone"))


def is_explanation_request(text: str) -> bool:
    """Only explicit explanation/advice requests may use the LLM fallback."""
    value = normalize(text)
    return any(phrase in value for phrase in (
        "설명해", "설명좀", "정리해", "분석해", "판단해", "추천해",
        "어떻게해야", "어떻게하면", "뭘해야", "무엇을해야", "왜위험",
        "어떤위험", "위험요소", "주의사항", "작업방법", "대처방법",
    ))


async def build_response_smart(intent: str, worker: dict, user_text: str = "") -> tuple[str, str | None]:
    fallback = build_response(intent, worker)
    if intent in FAST_INTENTS or (intent == "unknown" and not is_explanation_request(user_text)):
        return fallback
    freshness = worker.get("data_freshness")
    if freshness is not None and not freshness.get("vision") and not freshness.get("location"):
        return "최신 센서 정보가 없어 현재 상황은 확인 불가입니다. 현장 상태를 직접 확인해 주세요.", "play_tone"
    if not settings.use_gpt_response or not settings.openai_api_key:
        return fallback
    try:
        from openai import AsyncOpenAI

        ppe = worker.get("ppe", {})
        hazards = worker.get("hazards", {})
        location = f"X {worker.get('x', 0):.1f}, Y {worker.get('y', 0):.1f} m"
        risk = f"{worker.get('risk_score', 0)}점 / {worker.get('risk_level', '알 수 없음')}"
        if freshness is not None:
            if not freshness.get("location"):
                location = "확인 불가"
            if not freshness.get("vision"):
                ppe, hazards, risk = "확인 불가", "확인 불가", "확인 불가"
        context = (
            f"작업자 요청: {user_text}\n의도: {intent}\n"
            f"위치: {location}\n"
            f"위험도: {risk}\n"
            f"보호구: {ppe}\n감지 위험: {hazards}\n"
            "위 정보만 사용해 작업자에게 바로 말할 응답을 작성하세요."
        )
        client = AsyncOpenAI(
            api_key=settings.openai_api_key,
            timeout=settings.gpt_timeout_seconds,
            max_retries=0,
        )
        request = dict(
            model=settings.gpt_model,
            instructions=SYSTEM_PROMPT,
            input=context,
            max_output_tokens=settings.gpt_max_output_tokens,
        )
        if settings.gpt_model == "gpt-6-luna":
            request["reasoning"] = {"effort": "none"}
        response = await client.responses.create(**request)
        message = (response.output_text or "").strip()
        if not message:
            return fallback
        message = " ".join(message.split())[:120]
        speaker_command = "play_tone"
        return message, speaker_command
    except Exception as exc:
        logger.warning("OpenAI 응답 생성 실패, 고정 응답 사용: %s", exc)
        return fallback
