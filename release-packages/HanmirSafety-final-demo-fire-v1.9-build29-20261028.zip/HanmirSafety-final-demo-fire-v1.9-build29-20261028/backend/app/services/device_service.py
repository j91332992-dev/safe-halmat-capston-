import json

from sqlalchemy.orm import Session

from ..database import utcnow
from ..models.entities import Device
from ..schemas.api import DeviceRegister, Heartbeat


def register_device(db: Session, data: DeviceRegister) -> Device:
    device = db.get(Device, data.device_id)
    if not device:
        device = Device(device_id=data.device_id, device_type=data.device_type)
        db.add(device)
    for field in ("organization_id", "site_id", "worker_id", "helmet_id", "device_type", "firmware_version", "ip", "mac"):
        setattr(device, field, getattr(data, field))
    mark_device_seen(device)
    db.flush()
    return device


def mark_device_seen(device: Device, channel: str | None = None) -> None:
    now = utcnow()
    device.online = True
    device.last_seen = now
    if channel == "camera":
        device.last_camera_at = now
    elif channel == "audio":
        device.last_audio_at = now
    elif channel == "button":
        device.last_button_at = now
    elif channel == "uwb":
        device.last_uwb_at = now


def update_heartbeat(db: Session, data: Heartbeat) -> Device:
    device = db.get(Device, data.device_id)
    if not device:
        device = Device(
            device_id=data.device_id,
            device_type="position_device" if "uwb" in data.device_id else "assistant_device",
            organization_id=data.organization_id,
            site_id=data.site_id,
            worker_id=data.worker_id,
            helmet_id=data.helmet_id,
        )
        db.add(device)
    device.rssi = data.rssi
    # A device without a battery measurement circuit sends null. Preserve that
    # state, while storing a real percentage whenever the helmet reports one.
    device.battery = data.battery
    previous = json.loads(device.component_status_json or "{}")
    # Site heading calibration belongs to the server, not the firmware payload.
    status = dict(data.component_status)
    if "heading_calibration" in previous:
        status["heading_calibration"] = previous["heading_calibration"]
    if status.get("imu") == "ready" and isinstance(status.get("imu_yaw_deg"), (int, float)):
        status["imu_received_at"] = utcnow().isoformat() + "Z"
    device.component_status_json = json.dumps(status, ensure_ascii=False)
    device.last_error = data.error
    mark_device_seen(device)
    db.flush()
    return device
