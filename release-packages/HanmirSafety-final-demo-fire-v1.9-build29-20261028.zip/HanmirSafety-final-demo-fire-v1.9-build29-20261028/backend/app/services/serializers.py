from datetime import datetime
import json
import math
from typing import Any
from .orientation_service import live_status
from .operating_policy import data_health, policy


def parse_json(value: str | None, fallback: Any) -> Any:
    try:
        return json.loads(value or "")
    except (json.JSONDecodeError, TypeError):
        return fallback


def iso(value: datetime | None) -> str | None:
    return value.isoformat() + "Z" if value else None


def device_to_dict(device) -> dict:
    status = live_status(device.device_id, parse_json(device.component_status_json, {}))
    calibration = status.get("heading_calibration") or {}
    yaw = status.get("imu_yaw_deg")
    offset = calibration.get("offset_deg")
    heading = ((yaw + offset) % 360 if isinstance(yaw, (int, float))
               and isinstance(offset, (int, float)) and math.isfinite(yaw + offset)
               and status.get("imu") == "ready" else None)
    return {
        "device_id": device.device_id,
        "device_type": device.device_type,
        "organization_id": device.organization_id,
        "site_id": device.site_id,
        "worker_id": device.worker_id,
        "helmet_id": device.helmet_id,
        "ip": device.ip,
        "mac": device.mac,
        "rssi": device.rssi,
        "battery": device.battery,
        "firmware_version": device.firmware_version,
        "online": device.online,
        "component_status": status,
        "heading_deg": heading,
        "heading_at": status.get("imu_received_at"),
        "heading_calibrated_at": calibration.get("calibrated_at"),
        "last_error": device.last_error,
        "last_seen": iso(device.last_seen),
        "last_camera_at": iso(device.last_camera_at),
        "last_audio_at": iso(device.last_audio_at),
        "last_button_at": iso(device.last_button_at),
        "last_uwb_at": iso(device.last_uwb_at),
        "last_speaker_status": device.last_speaker_status,
        "last_speaker_at": iso(device.last_speaker_at),
        "data_health": {
            "heartbeat": data_health(device.last_seen, policy.heartbeat),
            "camera": data_health(device.last_camera_at, policy.camera),
            "heading": data_health(status.get("imu_received_at"), policy.heading,
                                   available=status.get("imu") == "ready"),
            # A heartbeat is not proof of a successful battery read or YOLO inference.
            "battery": data_health(None, policy.battery),
            "yolo": data_health(None, policy.yolo),
        },
    }


def worker_to_dict(worker) -> dict:
    from sqlalchemy.orm import object_session
    from .worker_operations import work_summary
    db = object_session(worker)
    from ..database import utcnow
    position_status = parse_json(worker.position_status_json, {})
    position_status.update(age_basis="server_acceptance", last_valid_at=iso(worker.last_valid_location_at),
                           last_valid_position=parse_json(worker.last_valid_location_json, None),
                           last_valid_age_seconds=max(0.0, (utcnow()-worker.last_valid_location_at).total_seconds())
                           if worker.last_valid_location_at else None)
    return {
        "work": work_summary(db, worker) if db else {"state": "off", "today_seconds": 0, "today_break_seconds": 0},
        "worker_id": worker.worker_id,
        "site_id": worker.site_id,
        "worker_name": worker.worker_name,
        "worker_role": worker.worker_role,
        "notes": worker.notes,
        "helmet_id": worker.helmet_id,
        "x": worker.x,
        "y": worker.y,
        "confidence": worker.confidence,
        "position_status": position_status,
        "data_health": {
            "uwb": data_health(worker.last_valid_location_at, policy.uwb,
                               age_basis="server_acceptance"),
        },
        "current_zone": worker.current_zone,
        "risk_score": worker.risk_score,
        "risk_level": worker.risk_level,
        "risk_reasons": parse_json(worker.reasons_json, []),
        "decision": (parse_json(worker.reasons_json, []) or [None])[0],
        "ppe": parse_json(worker.ppe_json, {}),
        "hazards": parse_json(worker.hazard_json, {}),
        "emergency": worker.emergency,
        "updated_at": iso(worker.updated_at),
    }

