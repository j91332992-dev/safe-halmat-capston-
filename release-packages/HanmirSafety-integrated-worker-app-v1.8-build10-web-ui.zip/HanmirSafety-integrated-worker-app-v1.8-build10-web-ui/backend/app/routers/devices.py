import json

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..database import get_db, utcnow
from ..models.entities import Device
from ..schemas.api import ComponentResultIn, DeviceCommandIn, DeviceRegister, Heartbeat
from ..services.command_service import queue_command
from ..services.device_service import mark_device_seen, register_device, update_heartbeat
from ..services.serializers import device_to_dict
from ..websocket import manager
from .auth import require_site

router = APIRouter(prefix="/api/devices", tags=["devices"])


@router.post("/register")
async def register(payload: DeviceRegister, db: Session = Depends(get_db)):
    device = register_device(db, payload)
    db.commit()
    result = device_to_dict(device)
    await manager.broadcast("device_registered", result)
    return result


@router.post("/heartbeat")
async def heartbeat(payload: Heartbeat, db: Session = Depends(get_db)):
    device = update_heartbeat(db, payload)
    db.commit()
    result = device_to_dict(device)
    await manager.broadcast("heartbeat", result)
    return {"ok": True, "server_mode": __import__("app.config", fromlist=["settings"]).settings.operation_mode, "device": result}


@router.post("/{device_id}/component-result")
async def component_result(device_id: str, payload: ComponentResultIn, db: Session = Depends(get_db)):
    device = db.get(Device, device_id)
    if not device:
        raise HTTPException(404, "장치를 찾을 수 없습니다.")
    if payload.component == "speaker":
        device.last_speaker_at = utcnow()
        device.last_speaker_status = f"{payload.status}: {payload.command_id or '-'}"
    mark_device_seen(device)
    device.last_error = payload.detail if payload.status == "error" else None
    db.commit()
    result = device_to_dict(device)
    await manager.broadcast("component_result", result)
    return {"ok": payload.status == "ok", "device": result}


@router.post("/{device_id}/command")
async def command(device_id: str, payload: DeviceCommandIn, site_id: str = Depends(require_site), db: Session = Depends(get_db)):
    device = db.get(Device, device_id)
    if not device or device.site_id != site_id:
        raise HTTPException(404, "장치를 찾을 수 없습니다.")
    record = queue_command(db, device_id, payload.command_type, payload.payload)
    delivered = await manager.send_device_command(
        device_id,
        {
            "command_id": record.command_id,
            "command_type": record.command_type,
            "payload": json.loads(record.payload_json),
        },
    )
    record.status = "delivered" if delivered else "queued"
    device.last_speaker_status = f"{record.command_type}: {record.status}"
    db.commit()
    result = {"command_id": record.command_id, "status": record.status, "delivered_connections": delivered}
    await manager.broadcast("device_command", {"device_id": device_id, "site_id": site_id, **result, "command_type": record.command_type})
    return result
