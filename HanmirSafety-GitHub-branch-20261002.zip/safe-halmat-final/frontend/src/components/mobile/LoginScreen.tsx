import {useState} from "react";
import type {FormEvent} from "react";
import {auth} from "../../services/api";
import {getStoredServerUrl} from "../../services/config";
import {ServerSettingsModal} from "./ServerSettingsModal";

export function LoginScreen({onLoggedIn}: {onLoggedIn: () => void}) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setSubmitting(true);
    setError("");
    try {
      await auth.login(username, password);
      onLoggedIn();
    } catch (caught) {
      const message = caught instanceof Error ? caught.message : "";
      if (!getStoredServerUrl()) {
        setError("우측 위 설정에서 관제 서버 주소를 먼저 입력해 주세요.");
      } else if (message.includes("401") || message.includes("올바르지 않습니다")) {
        setError("관리자 ID 또는 비밀번호를 다시 확인하세요.");
      } else {
        setError("관제 서버에 연결할 수 없습니다. 우측 위 설정을 확인하세요.");
      }
    } finally {
      setSubmitting(false);
    }
  };

  return <main className="admin-login-screen">
    <section className="admin-login-card">
      <button
        className="admin-login-settings"
        type="button"
        onClick={() => setSettingsOpen(true)}
        aria-label="관제 서버 설정"
        title="관제 서버 설정"
      >
        ⚙
      </button>
      <div className="admin-login-mark">H</div>
      <span className="admin-login-eyebrow">HANMIR SAFETY CONTROL</span>
      <h1>관리자 로그인</h1>
      <p>승인된 관리자만 현장 안전관제에 접근할 수 있습니다.</p>
      <form onSubmit={submit}>
        <label>관리자 ID<input autoComplete="username" value={username} onChange={event => setUsername(event.target.value)} placeholder="관리자 ID" required /></label>
        <label>비밀번호<input type="password" autoComplete="current-password" value={password} onChange={event => setPassword(event.target.value)} placeholder="비밀번호" required /></label>
        {error && <div className="admin-login-error">⚠️ {error}</div>}
        <button disabled={submitting} type="submit">{submitting ? "로그인 확인 중" : "로그인"}</button>
      </form>
      <small>무단 접근 시도는 허용되지 않습니다.</small>
    </section>
    <ServerSettingsModal
      isOpen={settingsOpen}
      onClose={() => setSettingsOpen(false)}
      onSaved={() => setSettingsOpen(false)}
    />
  </main>;
}
