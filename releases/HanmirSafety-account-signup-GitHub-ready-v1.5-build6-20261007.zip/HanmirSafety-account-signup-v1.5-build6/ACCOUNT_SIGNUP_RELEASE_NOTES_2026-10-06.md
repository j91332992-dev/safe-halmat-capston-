# 한미르 안전관제 계정별 현장분리 + 회원가입 버전

## 기준

- 친구가 수정한 `safe-halmat-capston--codex-mobile-app-handoff-20261006`을 기준으로 새 작업본을 생성했습니다.
- 원본 폴더는 변경하지 않았습니다.
- 기존 iPhone 안전 영역, 화면 반탄, 좌우 스크롤 방지, 하단 메뉴 고정, 로그인 화면의 서버 설정 버튼을 적용했습니다.

## 추가된 기능

- 로그인 화면의 `회원가입` 탭
- 회사/현장명, 관리자 ID, 비밀번호 등록
- 관리자 ID 중복 확인
- 대소문자만 다른 중복 ID 차단 (`TUTUS`, `tutus` 동일 처리)
- 서버의 고유 제약조건으로 동시 가입 시도에서도 중복 ID 차단
- 새 계정에 독립된 `site_id` 자동 발급
- 새 현장용 작업자, 안전모 장치, UWB 앵커 4개, 비상구, 기본 안전구역 자동 생성
- 가입 완료 후 새 계정의 현장으로 자동 로그인
- 기존 `TUTUS / 0000`, `TUTUS2 / 0000` 계정과 새 계정의 데이터는 서로 분리

## 확인 결과

- 백엔드 테스트: 63개 통과
- 신규 계정 가입 및 자동 로그인: 통과
- 기존 ID의 대소문자 중복 가입 차단: 통과
- 신규 계정의 현장/작업자/장치 분리: 통과
- 프론트엔드 TypeScript/Vite 빌드: 통과
- Capacitor iOS 동기화: 통과
- Xcode iPhoneOS Debug 빌드: 통과
- Apple Development 서명 검증: 통과

## 실행

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000
```

아이폰 앱의 서버 설정에는 같은 Wi-Fi에 연결된 맥북의 현재 IP와 `8000` 포트를 입력합니다.

## IPA

- 최신 확인용: `releases/HanmirSafety-account-signup-v1.1-build2.ipa`
- 앱 버전 `1.1`, 빌드 `2`
- 현재 Apple Development 서명으로 생성된 개발용 IPA입니다.
- App Store 배포용이 아니며, 현재 프로비저닝에 허용된 기기에서 테스트할 수 있습니다.

## 상용화 전 보완 권장

현재는 요청한 것처럼 누구나 회원가입을 할 수 있는 시연용 구조입니다. 실제 상용화 전에는 회사 인증, 이메일/휴대폰 확인, 승인 절차, 비밀번호 재설정, 로그인 시도 제한을 추가하는 것이 안전합니다.
