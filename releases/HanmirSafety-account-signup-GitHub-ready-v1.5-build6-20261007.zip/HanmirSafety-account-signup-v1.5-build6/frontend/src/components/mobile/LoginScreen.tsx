import {useState} from "react";
import type {FormEvent} from "react";
import {auth} from "../../services/api";
import {getStoredServerUrl} from "../../services/config";
import {ServerSettingsModal} from "./ServerSettingsModal";

type Mode = "login" | "register";
type Availability = "idle" | "checking" | "available" | "duplicate" | "invalid";

export function LoginScreen({onLoggedIn}: {onLoggedIn: () => void}) {
  const [mode, setMode] = useState<Mode>("login");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [passwordConfirm, setPasswordConfirm] = useState("");
  const [siteName, setSiteName] = useState("");
  const [availability, setAvailability] = useState<Availability>("idle");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);

  const changeMode = (nextMode: Mode) => {
    setMode(nextMode);
    setPassword("");
    setPasswordConfirm("");
    setError("");
    setAvailability("idle");
  };

  const checkUsername = async (): Promise<boolean> => {
    const candidate = username.trim();
    if (candidate.length < 4) {
      setAvailability("invalid");
      setError("관리자 ID는 4자 이상 입력하세요.");
      return false;
    }
    setAvailability("checking");
    try {
      const result = await auth.usernameAvailable(candidate);
      setAvailability(result.available ? "available" : result.reason ? "invalid" : "duplicate");
      if (!result.available) {
        setError(result.reason || "이미 사용 중인 관리자 ID입니다.");
      }
      return result.available;
    } catch (caught) {
      setAvailability("idle");
      const message = caught instanceof Error ? caught.message : "";
      setError(message.includes("Not Found")
        ? "현재 서버는 회원가입 기능이 없는 이전 버전입니다. 새 프로젝트의 백엔드를 실행하세요."
        : "관제 서버에 연결할 수 없습니다. 우측 위 설정을 확인하세요.");
      return false;
    }
  };

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setSubmitting(true);
    setError("");
    try {
      if (mode === "login") {
        await auth.login(username, password);
      } else {
        if (password !== passwordConfirm) {
          setError("비밀번호 확인이 일치하지 않습니다.");
          return;
        }
        if (!(await checkUsername())) {
          return;
        }
        await auth.register(username, password, siteName);
      }
      onLoggedIn();
    } catch (caught) {
      const message = caught instanceof Error ? caught.message : "";
      if (!getStoredServerUrl()) {
        setError("우측 위 설정에서 관제 서버 주소를 먼저 입력해 주세요.");
      } else if (message.includes("이미 사용 중")) {
        setAvailability("duplicate");
        setError("이미 사용 중인 관리자 ID입니다.");
      } else if (mode === "login" && message.includes("올바르지 않습니다")) {
        setError("관리자 ID 또는 비밀번호를 다시 확인하세요.");
      } else {
        setError(message || "관제 서버에 연결할 수 없습니다. 우측 위 설정을 확인하세요.");
      }
    } finally {
      setSubmitting(false);
    }
  };

  return <main className="admin-login-screen">
    <section className="admin-login-card">
      <button className="admin-login-settings" type="button" onClick={() => setSettingsOpen(true)} aria-label="관제 서버 설정" title="관제 서버 설정">⚙</button>
      <div className="admin-login-mark">H</div>
      <span className="admin-login-eyebrow">HANMIR SAFETY CONTROL</span>
      <h1>{mode === "login" ? "관리자 로그인" : "관리자 회원가입"}</h1>
      <p>{mode === "login" ? "승인된 관리자만 현장 안전관제에 접근할 수 있습니다." : "새 계정에는 독립된 현장 관제 공간이 자동으로 생성됩니다."}</p>

      <form onSubmit={submit}>
        {mode === "register" && <label>회사 또는 현장명 <span className="admin-optional-label">(선택)</span>
          <input autoComplete="organization" value={siteName} onChange={event => setSiteName(event.target.value)} placeholder="비워두면 아이디로 자동 생성됩니다" maxLength={100} />
        </label>}
        <label>관리자 ID
          <span className="admin-id-field">
            <input autoComplete="username" value={username} onChange={event => { setUsername(event.target.value); setAvailability("idle"); }} onBlur={() => { if (mode === "register" && username.trim()) void checkUsername(); }} placeholder="관리자 ID" minLength={mode === "register" ? 4 : undefined} maxLength={30} required />
            {mode === "register" && <button className="admin-id-check" type="button" disabled={availability === "checking"} onClick={() => void checkUsername()}>{availability === "checking" ? "확인 중" : "중복 확인"}</button>}
          </span>
          {mode === "register" && availability === "available" && <em className="admin-id-status available">사용 가능한 아이디입니다.</em>}
          {mode === "register" && availability === "duplicate" && <em className="admin-id-status unavailable">이미 사용 중인 아이디입니다.</em>}
          {mode === "register" && availability === "invalid" && <em className="admin-id-status unavailable">4~30자의 한글·영문·숫자 등을 사용하세요.</em>}
        </label>
        <label>비밀번호
          <input type="password" autoComplete={mode === "login" ? "current-password" : "new-password"} value={password} onChange={event => setPassword(event.target.value)} placeholder="비밀번호" minLength={mode === "register" ? 4 : undefined} maxLength={72} required />
        </label>
        {mode === "register" && <label>비밀번호 확인
          <input type="password" autoComplete="new-password" value={passwordConfirm} onChange={event => setPasswordConfirm(event.target.value)} placeholder="비밀번호를 다시 입력하세요" minLength={4} maxLength={72} required />
        </label>}
        {error && <div className="admin-login-error">⚠️ {error}</div>}
        <button disabled={submitting || (mode === "register" && availability === "duplicate")} type="submit">{submitting ? (mode === "login" ? "로그인 확인 중" : "계정 생성 중") : (mode === "login" ? "로그인" : "회원가입 후 시작")}</button>
      </form>
      <button className="admin-signup-link" type="button" onClick={() => changeMode(mode === "login" ? "register" : "login")}>
        {mode === "login" ? "계정이 없으신가요? 회원가입" : "이미 계정이 있으신가요? 로그인"}
      </button>
      <small>{mode === "login" ? "무단 접근 시도는 허용되지 않습니다." : "동일한 관리자 ID는 다시 가입할 수 없습니다."}</small>
      <span className="admin-login-version">v1.5 · 최종 모바일 관제 UI</span>
    </section>
    <ServerSettingsModal isOpen={settingsOpen} onClose={() => setSettingsOpen(false)} onSaved={() => setSettingsOpen(false)} />
  </main>;
}
