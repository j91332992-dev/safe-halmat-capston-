HANMIR iOS source build17, 2026-10-25.
Use macOS and Xcode. cd frontend; npm ci; npm run build:mobile; npx cap open ios.
Choose your signing team and connected iPhone, then build/archive.
This is source + synced web assets, NOT a signed IPA. iPhone runtime testing has NOT been done.
Use LAN server http://192.168.0.40:8000 only while on the same Wi-Fi; adjust for the actual server IP.
